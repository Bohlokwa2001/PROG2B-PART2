namespace ClinicSystemWinForms
{
    public class Patient { public int Id { get; set; } public string FullName { get; set; } = ""; public string Phone { get; set; } = ""; public string DOB { get; set; } = ""; }
    public class Appointment { public int Id { get; set; } public int PatientId { get; set; } public string DateTime { get; set; } = ""; public string Reason { get; set; } = ""; }
}