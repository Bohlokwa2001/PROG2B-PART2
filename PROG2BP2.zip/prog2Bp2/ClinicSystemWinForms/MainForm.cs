using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ClinicSystemWinForms
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void btnAddPatient_Click(object sender, EventArgs e)
        {
            var f = new AddPatientForm();
            f.ShowDialog();
        }

        private void btnListPatients_Click(object sender, EventArgs e)
        {
            var f = new ListPatientsForm();
            f.ShowDialog();
        }

        private void btnAddAppointment_Click(object sender, EventArgs e)
        {
            var f = new AddAppointmentForm();
            f.ShowDialog();
        }

        private void btnListAppointments_Click(object sender, EventArgs e)
        {
            var f = new ListAppointmentsForm();
            f.ShowDialog();
        }
    }
}
