using Microsoft.Data.Sqlite;
using System.Collections.Generic;

namespace ClinicSystemWinForms
{
    public static class Database
    {
        private const string DbFile = "clinic.db";
        public static void Initialize()
        {
            using var conn = new SqliteConnection($"Data Source={DbFile}");
            conn.Open();
            var cmd = conn.CreateCommand();
            cmd.CommandText = @"
                CREATE TABLE IF NOT EXISTS Patients (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    FullName TEXT NOT NULL,
                    Phone TEXT,
                    DOB TEXT
                );
                CREATE TABLE IF NOT EXISTS Appointments (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    PatientId INTEGER NOT NULL,
                    DateTime TEXT NOT NULL,
                    Reason TEXT,
                    FOREIGN KEY(PatientId) REFERENCES Patients(Id)
                );";
            cmd.ExecuteNonQuery();
        }

        public static void InsertPatient(Patient p)
        {
            using var conn = new SqliteConnection($"Data Source={DbFile}");
            conn.Open();
            var cmd = conn.CreateCommand();
            cmd.CommandText = "INSERT INTO Patients (FullName, Phone, DOB) VALUES ($name, $phone, $dob)";
            cmd.Parameters.AddWithValue("$name", p.FullName);
            cmd.Parameters.AddWithValue("$phone", p.Phone);
            cmd.Parameters.AddWithValue("$dob", p.DOB);
            cmd.ExecuteNonQuery();
        }

        public static List<Patient> GetPatients()
        {
            var list = new List<Patient>();
            using var conn = new SqliteConnection($"Data Source={DbFile}");
            conn.Open();
            var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT Id, FullName, Phone, DOB FROM Patients ORDER BY Id";
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new Patient { Id = reader.GetInt32(0), FullName = reader.GetString(1), Phone = reader.IsDBNull(2) ? "" : reader.GetString(2), DOB = reader.IsDBNull(3) ? "" : reader.GetString(3) });
            }
            return list;
        }

        public static void InsertAppointment(Appointment a)
        {
            using var conn = new SqliteConnection($"Data Source={DbFile}");
            conn.Open();
            var cmd = conn.CreateCommand();
            cmd.CommandText = "INSERT INTO Appointments (PatientId, DateTime, Reason) VALUES ($pid, $dt, $reason)";
            cmd.Parameters.AddWithValue("$pid", a.PatientId);
            cmd.Parameters.AddWithValue("$dt", a.DateTime);
            cmd.Parameters.AddWithValue("$reason", a.Reason);
            cmd.ExecuteNonQuery();
        }

        public static List<Appointment> GetAppointments()
        {
            var list = new List<Appointment>();
            using var conn = new SqliteConnection($"Data Source={DbFile}");
            conn.Open();
            var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT Id, PatientId, DateTime, Reason FROM Appointments ORDER BY DateTime";
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new Appointment { Id = reader.GetInt32(0), PatientId = reader.GetInt32(1), DateTime = reader.GetString(2), Reason = reader.IsDBNull(3) ? "" : reader.GetString(3) });
            }
            return list;
        }
    }
}
