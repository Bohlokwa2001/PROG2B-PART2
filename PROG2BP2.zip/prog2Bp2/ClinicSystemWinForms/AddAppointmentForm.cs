using System; using System.Windows.Forms;

namespace ClinicSystemWinForms
{
    public class AddAppointmentForm : Form
    {
        private TextBox txtPatientId, txtDateTime, txtReason; private Button btnSave;
        public AddAppointmentForm()
        {
            Text="Add Appointment"; Width=380; Height=240;
            Label l1=new Label(){Text="Patient Id:", Left=10, Top=20}; txtPatientId=new TextBox(){Left=100, Top=18, Width=240};
            Label l2=new Label(){Text="DateTime (yyyy-mm-dd HH:mm):", Left=10, Top=55}; txtDateTime=new TextBox(){Left=200, Top=53, Width=140};
            Label l3=new Label(){Text="Reason:", Left=10, Top=90}; txtReason=new TextBox(){Left=100, Top=88, Width=240};
            btnSave=new Button(){Text="Save", Left=140, Top=130, Width=80}; btnSave.Click+=BtnSave_Click;
            Controls.AddRange(new Control[]{l1, txtPatientId, l2, txtDateTime, l3, txtReason, btnSave});
        }
        private void BtnSave_Click(object sender, EventArgs e)
        {
            if(!int.TryParse(txtPatientId.Text, out int pid)){ MessageBox.Show("Invalid patient id"); return; }
            var a = new Appointment(){ PatientId = pid, DateTime = txtDateTime.Text, Reason = txtReason.Text };
            Database.InsertAppointment(a);
            MessageBox.Show("Appointment added.");
            this.Close();
        }
    }
}