namespace ClinicSystemWinForms
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing) { if (disposing && (components != null)) components.Dispose(); base.Dispose(disposing); }
        private void InitializeComponent()
        {
            this.btnAddPatient = new System.Windows.Forms.Button();
            this.btnListPatients = new System.Windows.Forms.Button();
            this.btnAddAppointment = new System.Windows.Forms.Button();
            this.btnListAppointments = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnAddPatient
            // 
            this.btnAddPatient.Location = new System.Drawing.Point(30, 20);
            this.btnAddPatient.Name = "btnAddPatient";
            this.btnAddPatient.Size = new System.Drawing.Size(200, 40);
            this.btnAddPatient.TabIndex = 0;
            this.btnAddPatient.Text = "Add Patient";
            this.btnAddPatient.UseVisualStyleBackColor = true;
            this.btnAddPatient.Click += new System.EventHandler(this.btnAddPatient_Click);
            // 
            // btnListPatients
            // 
            this.btnListPatients.Location = new System.Drawing.Point(30, 70);
            this.btnListPatients.Name = "btnListPatients";
            this.btnListPatients.Size = new System.Drawing.Size(200, 40);
            this.btnListPatients.TabIndex = 1;
            this.btnListPatients.Text = "List Patients";
            this.btnListPatients.UseVisualStyleBackColor = true;
            this.btnListPatients.Click += new System.EventHandler(this.btnListPatients_Click);
            // 
            // btnAddAppointment
            // 
            this.btnAddAppointment.Location = new System.Drawing.Point(30, 120);
            this.btnAddAppointment.Name = "btnAddAppointment";
            this.btnAddAppointment.Size = new System.Drawing.Size(200, 40);
            this.btnAddAppointment.TabIndex = 2;
            this.btnAddAppointment.Text = "Add Appointment";
            this.btnAddAppointment.UseVisualStyleBackColor = true;
            this.btnAddAppointment.Click += new System.EventHandler(this.btnAddAppointment_Click);
            // 
            // btnListAppointments
            // 
            this.btnListAppointments.Location = new System.Drawing.Point(30, 170);
            this.btnListAppointments.Name = "btnListAppointments";
            this.btnListAppointments.Size = new System.Drawing.Size(200, 40);
            this.btnListAppointments.TabIndex = 3;
            this.btnListAppointments.Text = "List Appointments";
            this.btnListAppointments.UseVisualStyleBackColor = true;
            this.btnListAppointments.Click += new System.EventHandler(this.btnListAppointments_Click);
            // 
            // MainForm
            // 
            this.ClientSize = new System.Drawing.Size(264, 231);
            this.Controls.Add(this.btnListAppointments);
            this.Controls.Add(this.btnAddAppointment);
            this.Controls.Add(this.btnListPatients);
            this.Controls.Add(this.btnAddPatient);
            this.Name = "MainForm";
            this.Text = "Clinic System - Main";
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Button btnAddPatient;
        private System.Windows.Forms.Button btnListPatients;
        private System.Windows.Forms.Button btnAddAppointment;
        private System.Windows.Forms.Button btnListAppointments;
    }
}
