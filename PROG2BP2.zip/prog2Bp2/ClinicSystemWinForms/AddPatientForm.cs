using System; using System.Windows.Forms;

namespace ClinicSystemWinForms
{
    public class AddPatientForm : Form
    {
        private TextBox txtName, txtPhone, txtDOB;
        private Button btnSave;
        public AddPatientForm()
        {
            Text = "Add Patient";
            Width = 350; Height = 220;
            Label l1 = new Label(){Text="Full name:", Left=10, Top=20};
            txtName = new TextBox(){Left=100, Top=18, Width=200};
            Label l2 = new Label(){Text="Phone:", Left=10, Top=55};
            txtPhone = new TextBox(){Left=100, Top=53, Width=200};
            Label l3 = new Label(){Text="DOB (yyyy-mm-dd):", Left=10, Top=90};
            txtDOB = new TextBox(){Left=140, Top=88, Width=160};
            btnSave = new Button(){Text="Save", Left=120, Top=130, Width=80};
            btnSave.Click += BtnSave_Click;
            Controls.AddRange(new Control[]{l1, txtName, l2, txtPhone, l3, txtDOB, btnSave});
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            var p = new Patient(){ FullName = txtName.Text, Phone = txtPhone.Text, DOB = txtDOB.Text };
            Database.InsertPatient(p);
            MessageBox.Show("Patient added.");
            this.Close();
        }
    }
}