using System;
using System.Windows.Forms;

namespace ClinicSystemWinForms
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            Database.Initialize(); // create DB if not present
            Application.Run(new MainForm());
        }
    }
}
