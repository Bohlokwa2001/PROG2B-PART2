using System; using System.Windows.Forms; using System.Text;

namespace ClinicSystemWinForms
{
    public class ListPatientsForm : Form
    {
        private TextBox txt;
        public ListPatientsForm()
        {
            Text = "List Patients"; Width = 500; Height = 400;
            txt = new TextBox(){Multiline=true, ReadOnly=true, ScrollBars=ScrollBars.Vertical, Dock=DockStyle.Fill};
            Controls.Add(txt);
            Load += ListPatientsForm_Load;
        }
        private void ListPatientsForm_Load(object sender, EventArgs e)
        {
            var list = Database.GetPatients();
            var sb = new StringBuilder();
            foreach(var p in list) sb.AppendLine($"{p.Id}: {p.FullName} | {p.Phone} | DOB: {p.DOB}");
            txt.Text = sb.ToString();
        }
    }
}