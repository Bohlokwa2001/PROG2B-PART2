using System; using System.Windows.Forms; using System.Text;

namespace ClinicSystemWinForms
{
    public class ListAppointmentsForm : Form
    {
        private TextBox txt;
        public ListAppointmentsForm()
        {
            Text="List Appointments"; Width=600; Height=400;
            txt=new TextBox(){Multiline=true, ReadOnly=true, ScrollBars=ScrollBars.Vertical, Dock=DockStyle.Fill};
            Controls.Add(txt); Load += ListAppointmentsForm_Load;
        }
        private void ListAppointmentsForm_Load(object sender, EventArgs e)
        {
            var list = Database.GetAppointments();
            var sb = new StringBuilder();
            foreach(var a in list) sb.AppendLine($"{a.Id}: PatientId={a.PatientId} | {a.DateTime} | {a.Reason}");
            txt.Text = sb.ToString();
        }
    }
}