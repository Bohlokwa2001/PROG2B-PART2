# Clinic System - Visual Studio WinForms (Student Submission)

**Student:** Bohlokwa Letsoso
**Project:** Clinic System (Desktop WinForms C#)
**Date:** 2025-10-21

## How to open
1. Open `ClinicSystemWinForms.sln` in Visual Studio 2022/2019 or Visual Studio Code with .NET SDK.
2. Restore NuGet packages (Microsoft.Data.Sqlite).
3. Build and Run. The `clinic.db` file will be created in the project's output directory.

## Files included
- ClinicSystemWinForms.csproj
- Program.cs, MainForm.cs, MainForm.Designer.cs
- AddPatientForm.cs, ListPatientsForm.cs, AddAppointmentForm.cs, ListAppointmentsForm.cs
- Models.cs, Database.cs
- screenshots/ (your provided screenshots)
- Part2_Report.md (detailed report for submission)

## Authorship statement
I wrote and tested the code myself and referenced Microsoft Docs and lecture materials. I adapted examples from official documentation and tested locally.

